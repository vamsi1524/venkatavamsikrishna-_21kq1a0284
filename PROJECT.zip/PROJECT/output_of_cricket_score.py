Python 3.12.3 (tags/v3.12.3:f6650f9, Apr  9 2024, 14:05:25) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
== RESTART: C:\Users\Vamsi\AppData\Local\Programs\Python\Python312\PROJECT.py ==
5
enter a over1
1 2 4 6 0 0
13 0
enter a over2
1 1 1 0 0 2
18 0
enter a over3
w 2 4 2 6 6
38 1
enter a over4
2 w 2 1 1 w
44 3
enter a over5
0 4 6 4 6 6
70 3
total score: 70 for 3 wicktes
{'virat': 14, 'rohith': 6, 'rakesh': 22, 'vamsi': 2, 'dhoni': 26, 'jaddu': 0, 'hardik': 0, 'gail': 0, 'dube': 0, 'bumra': 0, 'shami': 0}
